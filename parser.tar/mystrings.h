#ifndef _MYSTRINGS_H_
#define _MYSTRINGS_H_

#include <string.h>

int split(char *s, char *delimSet, char **list);
char *niceStringIn(char *s);
char *niceStringOut(char *s);

#endif
